from flask import Flask, request, render_template
import pyodbc

app = Flask(__name__)

# Database connection configuration
server = 'localhost'  # Your server name
database = 'SummerActivities'  # Your database name
driver = '{ODBC Driver 17 for SQL Server}'
conn_str = r'DRIVER={SQL Server};SERVER=localhost\SQLEXPRESS;DATABASE=SummerActivities;Trusted_Connection=yes;'


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Retrieve form data
        location = request.form['location']
        budget = request.form['budget']
        gender = request.form.get('gender', '')
        coedVsNot = request.form.get('coedVsNot', '')

        # Connect to the database
        print("Connecting to the database...")
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        print("Connection established.")

        # Construct the SQL query based on user input
        sql = "SELECT CampName, Address, Price, Gender, Website FROM {} WHERE Price <= ?".format(location)
        params = [budget]

        if gender:
            coedVsSeparate = request.form.get('coedVsSeparate', '')  # Get the selected value from the form
            if coedVsSeparate == "Co-ed":
                sql += " AND (gender = ? OR gender = 'Co-ed')"
            else:
                sql += " AND gender = ?"
            params.append(gender)

        # Execute SQL query
        print("Executing SQL query:", sql)
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        print("Query executed successfully.")

        # Close the database connection
        cursor.close()
        conn.close()
        print("Connection closed.")

        # Render the template with the retrieved data
        return render_template('result.html', rows=rows)

    # Render the form page
    return render_template('form.html')


@app.route('/result.html', methods=['GET', 'POST'])
def result():
    # This route handles requests to '/result.html' and renders the result.html template.
    # You can optionally provide additional functionality here if needed.
    return render_template('result.html')


if __name__ == '__main__':
    app.run(debug=True)
